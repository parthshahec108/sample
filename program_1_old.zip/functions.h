#include <stdlib.h>

/* Function declaration */
int* get_array(int size);
int sum_of_element(int* start_add, int length);

/* Function definition */
int* get_array(int size) 
{
	int* add = NULL;
	add = malloc(size * sizeof(int));
	return add;	
}

int sum_of_element(int* start_add, int length)
{
	int i = 0, sum = 0;
	for (i = 0; i < length; i++) {
		sum = sum + (*(start_add + i));		
	}	
	return sum;
}
